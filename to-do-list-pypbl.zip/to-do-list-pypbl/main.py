import sqlite3
import hashlib
from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivymd.uix.list import TwoLineAvatarIconListItem, IRightBodyTouch
from kivymd.uix.selectioncontrol import MDCheckbox
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton, MDRaisedButton
from kivymd.uix.pickers import MDDatePicker, MDTimePicker
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDIconButton
from datetime import datetime
from kivy.core.window import Window
from kivy.uix.screenmanager import ScreenManager
from kivy.properties import BooleanProperty
from kivy.lang import Builder
# --- STEP 3.1: Add new imports ---
from kivy.clock import Clock
from plyer import notification

Window.size = (670, 760)

class RightCheckboxContainer(IRightBodyTouch, MDBoxLayout):
    adaptive_width = True

class TaskItem(TwoLineAvatarIconListItem):
    done = BooleanProperty(False)

    def __init__(self, task_id, title, due_date, due_time, done, **kwargs):
        super().__init__(**kwargs)
        self.task_id = task_id
        self.text = title
        self.done = bool(done)
        
        due_string_parts = []
        if due_date:
            due_string_parts.append(due_date)
        if due_time:
            due_string_parts.append(due_time)

        if due_string_parts:
            self.secondary_text = f"Due: {' at '.join(due_string_parts)}"
        else:
            self.secondary_text = "No due date"


class LoginScreen(MDScreen): pass
class SignupScreen(MDScreen): pass
class TodoScreen(MDScreen): pass

class TodoApp(MDApp):
    dialog = None 

    def build(self):
        self.theme_cls.primary_palette = "Indigo"
        self.conn = sqlite3.connect("todo_users.db")
        self.cursor = self.conn.cursor()
        self.create_tables()
        self.current_user = None
        self.selected_due_date = None
        self.selected_due_time = None
        
        # --- STEP 3.3: Schedule the notification check to run every 60 seconds ---
        Clock.schedule_interval(self.check_for_notifications, 60)
        
        # Kivy automatically loads the 'todoapp.kv' file
        return Builder.load_file('main.kv')

    def create_tables(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL
            )""")
        # --- STEP 3.2: Add a 'notified' column to the tasks table ---
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                title TEXT,
                due_date TEXT,
                due_time TEXT,
                done INTEGER DEFAULT 0,
                notified INTEGER DEFAULT 0,
                FOREIGN KEY (username) REFERENCES users (username)
            )""")
        self.conn.commit()

    def hash_password(self, pwd):
        return hashlib.sha256(pwd.encode()).hexdigest()

    # ---------- Auth methods ----------
    def signup_user(self, username, password):
        if not username or not password:
            self.show_dialog("Error", "Username and password required")
            return
        try:
            self.cursor.execute("INSERT INTO users VALUES (?, ?)",
                                (username, self.hash_password(password)))
            self.conn.commit()
            self.show_dialog("Success", "Account created successfully!")
            self.change_screen("login")
        except sqlite3.IntegrityError:
            self.show_dialog("Error", "Username already exists")

    def login_user(self, username, password):
        self.cursor.execute("SELECT password FROM users WHERE username=?", (username,))
        row = self.cursor.fetchone()
        if row and row[0] == self.hash_password(password):
            self.current_user = username
            self.load_tasks()
            self.change_screen("todo")
        else:
            self.show_dialog("Error", "Invalid username or password")

    def logout_user(self):
        self.current_user = None
        self.root.get_screen('login').ids.login_username.text = ""
        self.root.get_screen('login').ids.login_password.text = ""
        self.root.get_screen('todo').ids.task_list.clear_widgets()
        self.change_screen("login")
        
    # ---------- Tasks ----------
    def add_task(self, title):
        if not title.strip():
            self.show_dialog("Error", "Task title cannot be empty")
            return
            
        # --- MODIFIED: Insert statement now includes the 'notified' field (defaulting to 0) ---
        self.cursor.execute(
            "INSERT INTO tasks(username, title, due_date, due_time, notified) VALUES (?, ?, ?, ?, 0)",
            (self.current_user, title, self.selected_due_date, self.selected_due_time))
        self.conn.commit()
        
        self.selected_due_date = None
        self.selected_due_time = None
        self.load_tasks()
        
        task_textfield = self.root.get_screen("todo").ids.task_title
        task_textfield.text = ""
        task_textfield.hint_text = "Enter a new task"

    def load_tasks(self):
        # This method works as is, no change needed here.
        if not self.current_user:
            return
        todo_screen = self.root.get_screen("todo")
        todo_screen.ids.welcome_label.text = f"{self.current_user}'s To-Do List"
        todo_screen.ids.task_list.clear_widgets()

        self.cursor.execute("SELECT id, title, due_date, due_time, done FROM tasks WHERE username=? ORDER BY due_date, due_time",
                            (self.current_user,))
        for task_id, title, due_date, due_time, done in self.cursor.fetchall():
            item = TaskItem(task_id, title, due_date, due_time, done)
            todo_screen.ids.task_list.add_widget(item)

    def mark_done(self, task_id, value):
        self.cursor.execute("UPDATE tasks SET done=? WHERE id=?",
                            (1 if value else 0, task_id))
        self.conn.commit()

    def delete_task(self, task_id):
        self.cursor.execute("DELETE FROM tasks WHERE id=?", (task_id,))
        self.conn.commit()
        self.load_tasks()
        
    # --- STEP 3.4: The new notification checking function ---
    def check_for_notifications(self, *args):
        # Only check if a user is logged in
        if not self.current_user:
            return

        try:
            now = datetime.now()
            current_date = now.strftime("%Y-%m-%d")
            current_time = now.strftime("%I:%M %p")

            # Find tasks that are due now, are not done, and haven't been notified yet
            self.cursor.execute("""
                SELECT id, title FROM tasks
                WHERE username = ? AND due_date = ? AND due_time = ? AND done = 0 AND notified = 0
            """, (self.current_user, current_date, current_time))
            
            tasks_to_notify = self.cursor.fetchall()

            for task_id, title in tasks_to_notify:
                # Send notification
                notification.notify(
                    title="TASK DUE !",
                    message=f"Your task '{title}' is due now.",
                    app_name="To-Do App"
                )
                
                # Update the task to mark it as notified
                self.cursor.execute("UPDATE tasks SET notified = 1 WHERE id = ?", (task_id,))
                self.conn.commit()

        except Exception as e:
            print(f"Error checking notifications: {e}")


    # ---------- Date and Time Pickers ----------
    def show_date_picker(self):
        initial_date = datetime.now().date()
        picker = MDDatePicker(year=initial_date.year, month=initial_date.month, day=initial_date.day)
        picker.bind(on_save=self.on_date_selected)
        picker.open()

    def on_date_selected(self, instance, value, date_range):
        self.selected_due_date = value.strftime("%Y-%m-%d")
        self.update_hint_text()

    def show_time_picker(self):
        picker = MDTimePicker()
        picker.bind(on_save=self.on_time_selected)
        picker.open()

    def on_time_selected(self, instance, time):
        self.selected_due_time = time.strftime("%I:%M %p")
        self.update_hint_text()
        
    def update_hint_text(self):
        hint_parts = []
        if self.selected_due_date:
            hint_parts.append(self.selected_due_date)
        if self.selected_due_time:
            hint_parts.append(self.selected_due_time)
        
        if hint_parts:
            self.root.get_screen("todo").ids.task_title.hint_text = f"Due: {' at '.join(hint_parts)}"
        else:
            self.root.get_screen("todo").ids.task_title.hint_text = "Enter a new task"


    # ---------- Utils ----------
    def change_screen(self, name):
        self.root.current = name

    def show_dialog(self, title, text):
        if not self.dialog:
            self.dialog = MDDialog(
                title=title,
                text=text,
                buttons=[
                    MDRaisedButton(
                        text="OK", on_release=self.close_dialog
                    )
                ],
            )
        else: 
            self.dialog.title = title
            self.dialog.text = text
            
        self.dialog.open()

    def close_dialog(self, *args):
        if self.dialog:
            self.dialog.dismiss()

    def on_stop(self):
        try:
            self.conn.close()
        except Exception as e:
            print(f"Error closing DB connection: {e}")

if __name__ == "__main__":
    TodoApp().run()