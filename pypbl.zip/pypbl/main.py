import sqlite3
import hashlib
import requests
from kivy.lang import Builder
from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivymd.uix.list import TwoLineAvatarIconListItem, IRightBodyTouch, IconLeftWidget
from kivymd.uix.selectioncontrol import MDCheckbox
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton, MDRaisedButton
from kivymd.uix.pickers import MDDatePicker, MDTimePicker
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDIconButton, MDFloatingActionButton 
from datetime import datetime
from kivy.core.window import Window
from kivy.uix.screenmanager import ScreenManager
from kivy.properties import BooleanProperty, StringProperty, ObjectProperty 
from kivy.clock import Clock
from plyer import notification
from kivy.utils import platform

class TaskDialogContent(MDBoxLayout):
    pass
# --- MODIFIED KV for Android App ---
KV = '''
<TaskItem>:
    RightCheckboxContainer:
        id: right_widgets
        MDCheckbox:
            active: root.done
            on_active: app.mark_done(root.task_id, self.active)
        MDIconButton:
            icon: "trash-can-outline"
            on_release: app.delete_task(root.task_id)

<TaskDialogContent>:
    orientation: "vertical"
    spacing: "12dp"
    size_hint_y: None
    height: "220dp" # Adjusted height
    padding: "20dp"

    MDTextField:
        id: dialog_task_title
        hint_text: "Task Title"
        mode: "rectangle"

    MDBoxLayout:
        adaptive_height: True
        spacing: "10dp"
        
        MDIconButton:
            id: date_button
            icon: "calendar"
            on_release: app.show_date_picker()  # <-- ADD THIS LINE

        MDLabel:
            id: date_label
            text: "Select due date"
            valign: "middle"
            pos_hint: {"center_y": 0.5}

    MDBoxLayout:
        adaptive_height: True
        spacing: "10dp"

        MDIconButton:
            id: time_button
            icon: "clock-outline"
            on_release: app.show_time_picker()  # <-- ADD THIS LINE
        
        MDLabel:
            id: time_label
            text: "Select due time"
            valign: "middle"
            pos_hint: {"center_y": 0.5}

ScreenManager:
    LoginScreen:
    SignupScreen:
    TodoScreen:

# --- MODIFIED ---
# Wrapped the login form in a centered MDCard for a cleaner look
<LoginScreen>:
    name: 'login'
    MDFloatLayout:
        MDCard:
            orientation: 'vertical'
            padding: 40
            spacing: 20
            size_hint: .8, None
            height: self.minimum_height
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            elevation: 2
            radius: [15, 15, 15, 15]

            MDIcon:
                icon: "login"
                halign: "center"
                font_size: "48sp"
                theme_text_color: "Primary"
                padding_y: 10

            MDLabel:
                text: "Login"
                halign: "center"
                font_style: "H4"
                padding_y: 10 # Reduced padding

            MDTextField:
                id: login_username
                hint_text: "Username"
                icon_right: "account"
                mode: "rectangle"

            MDTextField:
                id: login_password
                hint_text: "Password"
                password: True
                icon_right: "lock"
                mode: "rectangle"

            MDRaisedButton:
                text: "Login"
                pos_hint: {"center_x": 0.5}
                on_release: app.login_user(login_username.text, login_password.text)
                elevation: 2

            MDTextButton:
                text: "Don't have an account? Sign Up"
                pos_hint: {"center_x": 0.5}
                on_release: app.change_screen('signup')

# --- MODIFIED ---
# Wrapped the signup form in a centered MDCard
<SignupScreen>:
    name: 'signup'
    MDFloatLayout:
        MDCard:
            orientation: 'vertical'
            padding: 40
            spacing: 20
            size_hint: .8, None
            height: self.minimum_height
            pos_hint: {"center_x": 0.5, "center_y": 0.5}
            elevation: 2
            radius: [15, 15, 15, 15]

            MDIcon:
                icon: "account-plus"
                halign: "center"
                font_size: "48sp"
                theme_text_color: "Primary"
                padding_y: 10

            MDLabel:
                text: "Sign Up"
                halign: "center"
                font_style: "H4"
                padding_y: 10

            MDTextField:
                id: signup_username
                hint_text: "Username"
                icon_right: "account"
                mode: "rectangle"

            MDTextField:
                id: signup_password
                hint_text: "Password"
                password: True
                icon_right: "lock"
                mode: "rectangle"

            MDRaisedButton:
                text: "Sign Up"
                pos_hint: {"center_x": 0.5}
                on_release: app.signup_user(signup_username.text, signup_password.text)
                elevation: 2

            MDTextButton:
                text: "Already have an account? Login"
                pos_hint: {"center_x": 0.5}
                on_release: app.change_screen('login')

# --- MODIFIED ---
# Rebuilt the TodoScreen with TopAppBar, ScrollView, and FAB
<TodoScreen>:
    name: 'todo'
    MDBoxLayout:
        orientation: 'vertical'
        
        MDTopAppBar:
            id: top_bar
            title: "Your To-Do List"
            right_action_items: [["logout", lambda x: app.logout_user()]]
            elevation: 2

        MDFloatLayout:
            # This layout will hold the list and the floating button
            ScrollView:
                MDList:
                    id: task_list
                    padding: "10dp"
            
            MDFloatingActionButton:
                icon: "plus"
                pos_hint: {"right": 1, "bottom": 1}
                elevation: 2
                md_bg_color: app.theme_cls.primary_color
                on_release: app.show_add_task_dialog()
                # Use margins to keep it off the edge
                x: root.width - self.width - dp(16)
                y: dp(16)
'''

class RightCheckboxContainer(IRightBodyTouch, MDBoxLayout):
    adaptive_width = True

class TaskItem(TwoLineAvatarIconListItem):
    done = BooleanProperty(False)
    
    def __init__(self, task_id, title, due_datetime_str, done, **kwargs):
        super().__init__(**kwargs)
        self.task_id = task_id
        self.text = title
        self.done = bool(done)
        
        # --- MODIFIED ---
        # Add visual feedback for completed tasks
        if self.done:
            self.theme_text_color = "Secondary"
            self.secondary_theme_text_color = "Secondary"

        if due_datetime_str:
            try:
                dt_obj = datetime.fromisoformat(due_datetime_str)
                self.secondary_text = dt_obj.strftime("Due: %Y-%m-%d at %I:%M %p")
            except ValueError:
                self.secondary_text = "Invalid due date"
        else:
            self.secondary_text = "No due date"


class LoginScreen(MDScreen): pass
class SignupScreen(MDScreen): pass
class TodoScreen(MDScreen): pass

class TodoApp(MDApp):
    # --- MODIFIED --- 
    # Removed old dialog, will create a new one
    task_dialog = None
    dialog_content = None 

    # --- NEW: Define your server URL ---
    # You must change this IP to your computer's network IP
    server_url = "http://192.168.1.14:5000" # <--- IMPORTANT!

    def build(self):
        self.theme_cls.primary_palette = "Indigo"
        
        # --- CRITICAL FIX ---
        # Load the KV string FIRST. This teaches Kivy all the rules.
        # We store the root widget in a variable.
        root_widget = Builder.load_string(KV)
        # --- END FIX ---
        
        self.conn = sqlite3.connect("local_user.db")
        self.cursor = self.conn.cursor()
        self.create_local_user_table()
        self.current_user = None
        self.selected_due_date = None 
        self.selected_due_time = None 
        
        self.task_cache = {} 
        self.request_android_permissions()
        Clock.schedule_interval(self.check_for_notifications, 1) 
        
        # --- MODIFIED ---
        # NOW we create the instance. Kivy will see it's a TaskDialogContent
        # and correctly apply the KV rule, populating its .ids
        if not self.task_dialog:
            self.dialog_content = TaskDialogContent()
            self.task_dialog = MDDialog(
                title="Add New Task",
                type="custom",
                content_cls=self.dialog_content,
                buttons=[
                    MDFlatButton(
                        text="CANCEL", 
                        on_release=lambda x: self.task_dialog.dismiss()
                    ),
                    MDRaisedButton(
                        text="ADD",
                        on_release=self.add_task_from_dialog
                    ),
                ],
            )
        return root_widget

    def create_local_user_table(self):
        # This is just for the app to remember who is logged in
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS local_user (
                username TEXT PRIMARY KEY
            )""")
        self.conn.commit()

    # ... (request_android_permissions, create_tables, hash_password remain unchanged) ...
    def request_android_permissions(self):
        if platform == 'android':
            try:
                from android.permissions import request_permissions, Permission
                request_permissions([Permission.POST_NOTIFICATIONS])
            except ImportError:
                print("Could not import android.permissions. Are you on Android?")
            except Exception as e:
                print(f"Error requesting permissions: {e}")

    # ---------- Auth methods (unchanged) ----------
    # ---------- Auth methods (MODIFIED) ----------
    def signup_user(self, username, password):
        if not username or not password:
            self.show_dialog("Error", "Username and password required")
            return
        
        # Talk to the server
        try:
            response = requests.post(
                f"{self.server_url}/signup",
                json={"username": username, "password": password}
            )
            if response.status_code == 201: # 201 = Created
                self.show_dialog("Success", "Account created successfully!")
                self.change_screen("login")
            else:
                self.show_dialog("Error", response.json().get("error", "Unknown error"))
        except requests.exceptions.ConnectionError:
            self.show_dialog("Error", "Could not connect to server")

    def login_user(self, username, password):
        # Talk to the server
        try:
            response = requests.post(
                f"{self.server_url}/login",
                json={"username": username, "password": password}
            )
            if response.status_code == 200:
                self.current_user = username
                # Save login locally
                self.cursor.execute("DELETE FROM local_user") # Clear old user
                self.cursor.execute("INSERT INTO local_user VALUES (?)", (username,))
                self.conn.commit()
                
                self.load_tasks() 
                self.change_screen("todo")
            else:
                self.show_dialog("Error", "Invalid username or password")
        except requests.exceptions.ConnectionError:
            self.show_dialog("Error", "Could not connect to server")

    def logout_user(self):
        self.current_user = None
        # Clear local login
        self.cursor.execute("DELETE FROM local_user")
        self.conn.commit()
        
        if self.root:
            self.root.get_screen('login').ids.login_username.text = ""
            self.root.get_screen('login').ids.login_password.text = ""
            self.root.get_screen('todo').ids.task_list.clear_widgets()
            self.change_screen("login")
            
    # ---------- Tasks ----------
    
    # --- NEW ---
    # This method is called by the FAB to reset and show the dialog
    def show_add_task_dialog(self):
        # ... (This function is unchanged) ...
        self.selected_due_date = None
        self.selected_due_time = None
        self.dialog_content.ids.dialog_task_title.text = ""
        self.dialog_content.ids.date_label.text = "Select due date"
        self.dialog_content.ids.time_label.text = "Select due time"
        self.task_dialog.open()

    def add_task_from_dialog(self, *args):
        title = self.dialog_content.ids.dialog_task_title.text
        if not title.strip():
            self.dialog_content.ids.dialog_task_title.error = True
            self.dialog_content.ids.dialog_task_title.helper_text = "Title cannot be empty"
            return
            
        due_datetime_str = None
        if self.selected_due_date and self.selected_due_time:
            dt_obj = datetime.combine(self.selected_due_date, self.selected_due_time)
            due_datetime_str = dt_obj.isoformat()
        
        # Send data to server
        try:
            response = requests.post(
                f"{self.server_url}/add_task",
                json={
                    "username": self.current_user,
                    "title": title,
                    "due_datetime": due_datetime_str
                }
            )
            if response.status_code == 201:
                self.load_tasks() # Reload all tasks from server
                self.task_dialog.dismiss()
            else:
                self.show_dialog("Error", "Failed to add task")
        except requests.exceptions.ConnectionError:
            self.show_dialog("Error", "Could not connect to server")


    def load_tasks(self):
        if not self.current_user:
            return
            
        todo_screen = self.root.get_screen("todo")
        todo_screen.ids.task_list.clear_widgets()
        
        # --- NEW: Clear cache before reloading ---
        self.task_cache = {} 
        
        try:
            response = requests.get(f"{self.server_url}/tasks/{self.current_user}")
            if response.status_code != 200:
                self.show_dialog("Error", "Could not load tasks")
                return

            tasks = response.json()
            for task in tasks:
                item = TaskItem(
                    task_id=task['id'],
                    title=task['title'],
                    due_datetime_str=task['due_datetime'],
                    done=task['done']
                )
                icon_name = "check-circle" if task['done'] else "circle-outline"
                icon = IconLeftWidget(icon=icon_name)
                if task['done']:
                    icon.theme_text_color = "Secondary"
                item.add_widget(icon)
                todo_screen.ids.task_list.add_widget(item)
                
                # --- NEW: Rebuild the cache from server data ---
                if not task['done'] and not task['notified'] and task['due_datetime']:
                    self.task_cache[task['id']] = {
                        "title": task['title'],
                        "due_datetime": task['due_datetime']
                    }
                    
        except requests.exceptions.ConnectionError:
            self.show_dialog("Error", "Could not connect to server")

    def mark_done(self, task_id, value):
        try:
            requests.post(
                f"{self.server_url}/mark_done/{task_id}",
                json={"done": value}
            )
            # Easiest way to update UI is to just reload
            self.load_tasks()
        except requests.exceptions.ConnectionError:
            self.show_dialog("Error", "Could not connect to server")


    def delete_task(self, task_id):
        try:
            requests.post(f"{self.server_url}/delete_task/{task_id}")
            self.load_tasks() # Reload
        except requests.exceptions.ConnectionError:
            self.show_dialog("Error", "Could not connect to server")
        
    def check_for_notifications(self, *args):
        if not self.current_user:
            return

        try:
            now = datetime.now()
            
            for task_id, task_info in list(self.task_cache.items()):
                task_due_time = datetime.fromisoformat(task_info["due_datetime"])
                if now >= task_due_time:
                    
                    title = task_info["title"]
                    print(f"Sending notification for: {title}")
                    notification.notify(
                        title="TASK DUE!",
                        message=f"Your task '{title}' is due now.",
                        app_name="To-Do App"
                    )
                    
                    # --- MODIFIED: Tell the server, not the local DB ---
                    try:
                        requests.post(f"{self.server_url}/mark_notified/{task_id}")
                    except requests.exceptions.ConnectionError:
                        print(f"Could not mark task {task_id} as notified on server")
                    # --- END MODIFIED ---
                    
                    # Remove from local cache so we don't notify again this session
                    del self.task_cache[task_id]

        except Exception as e:
            print(f"Error checking notifications: {e}")

    # ---------- Date and Time Pickers (Updated) ----------
    def show_date_picker(self):
        # ... (this function is fine as-is)
        initial_date = self.selected_due_date or datetime.now().date()
        picker = MDDatePicker(year=initial_date.year, month=initial_date.month, day=initial_date.day)
        picker.bind(on_save=self.on_date_selected)
        picker.open()

    def on_date_selected(self, instance, value, date_range):
        self.selected_due_date = value 
        # Access the saved instance
        self.dialog_content.ids.date_label.text = value.strftime("%Y-%m-%d")

    def show_time_picker(self):
        # ... (this function is fine as-is)
        initial_time = self.selected_due_time
        picker = MDTimePicker()
        if initial_time:
            picker.set_time(initial_time)
        picker.bind(on_save=self.on_time_selected)
        picker.open()

    def on_time_selected(self, instance, time):
        self.selected_due_time = time
        # Access the saved instance
        self.dialog_content.ids.time_label.text = time.strftime("%I:%M %p")
        
    # --- REMOVED 'update_hint_text' as it's no longer needed ---

    # ---------- Utils ----------
    def change_screen(self, name):
        if self.root:
            self.root.current = name

    # --- MODIFIED ---
    # Using a single, reusable dialog for errors
    def show_dialog(self, title, text):
        if not hasattr(self, 'error_dialog'):
            self.error_dialog = MDDialog(
                title=title,
                text=text,
                buttons=[
                    MDRaisedButton(
                        text="OK", on_release=lambda x: self.error_dialog.dismiss()
                    )
                ],
            )
        else:
            self.error_dialog.title = title
            self.error_dialog.text = text
            
        self.error_dialog.open()

    # --- REMOVED 'close_dialog' as it's part of the lambda ---

    def on_stop(self):
        try:
            self.conn.close()
        except Exception as e:
            print(f"Error closing DB connection: {e}")

if __name__ == "__main__":
    TodoApp().run()