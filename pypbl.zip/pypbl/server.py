import sqlite3
import hashlib
from flask import Flask, request, jsonify

# --- Database Setup (Identical to your Kivy app) ---

def get_db_connection():
    conn = sqlite3.connect('master_todo.db')
    conn.row_factory = sqlite3.Row
    return conn

def create_tables():
    conn = get_db_connection()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL
        )""")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            title TEXT,
            due_datetime TEXT,
            done INTEGER DEFAULT 0,
            notified INTEGER DEFAULT 0,
            FOREIGN KEY (username) REFERENCES users (username)
        )""")
    conn.commit()
    conn.close()

def hash_password(pwd):
    return hashlib.sha256(pwd.encode()).hexdigest()

# --- Initialize Flask App ---

app = Flask(__name__)
create_tables() # Create tables when server starts

# --- API Endpoints ---

@app.route('/signup', methods=['POST'])
def signup_user():
    data = request.json
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({"error": "Username and password required"}), 400

    try:
        conn = get_db_connection()
        conn.execute("INSERT INTO users VALUES (?, ?)",
                     (username, hash_password(password)))
        conn.commit()
        conn.close()
        return jsonify({"message": "Account created successfully"}), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "Username already exists"}), 409

@app.route('/login', methods=['POST'])
def login_user():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    conn = get_db_connection()
    user = conn.execute("SELECT password FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    
    if user and user['password'] == hash_password(password):
        return jsonify({"message": "Login successful", "username": username}), 200
    else:
        return jsonify({"error": "Invalid username or password"}), 401

@app.route('/tasks/<username>', methods=['GET'])
def get_tasks(username):
    conn = get_db_connection()
    tasks_cursor = conn.execute(
        # --- MODIFIED: Added 'notified' to the SELECT ---
        "SELECT id, title, due_datetime, done, notified FROM tasks WHERE username=? ORDER BY done, due_datetime",
        (username,)
    )
    tasks = [dict(row) for row in tasks_cursor.fetchall()]
    conn.close()
    return jsonify(tasks), 200

@app.route('/add_task', methods=['POST'])
def add_task():
    data = request.json
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO tasks(username, title, due_datetime, notified) VALUES (?, ?, ?, 0)",
            (data['username'], data['title'], data.get('due_datetime'))
        )
        new_task_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return jsonify({"message": "Task added", "id": new_task_id}), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/mark_done/<int:task_id>', methods=['POST'])
def mark_done(task_id):
    data = request.json
    is_done = 1 if data.get('done') else 0
    
    conn = get_db_connection()
    conn.execute("UPDATE tasks SET done=? WHERE id=?", (is_done, task_id))
    conn.commit()
    conn.close()
    return jsonify({"message": "Task updated"}), 200

@app.route('/mark_notified/<int:task_id>', methods=['POST'])
def mark_notified(task_id):
    try:
        conn = get_db_connection()
        conn.execute("UPDATE tasks SET notified = 1 WHERE id = ?", (task_id,))
        conn.commit()
        conn.close()
        return jsonify({"message": "Task marked as notified"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/delete_task/<int:task_id>', methods=['POST']) # Using POST for simplicity
def delete_task(task_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM tasks WHERE id=?", (task_id,))
    conn.commit()
    conn.close()
    return jsonify({"message": "Task deleted"}), 200


# --- Run the Server ---
if __name__ == '__main__':
    # Runs on port 5000 and is accessible from any device on your network
    app.run(host='0.0.0.0', port=5000, debug=True)